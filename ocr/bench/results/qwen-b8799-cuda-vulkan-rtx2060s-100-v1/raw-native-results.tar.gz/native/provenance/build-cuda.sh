#!/bin/sh
set -eu
cd /srv/usnm-pair-786
export HOME="$PWD/home" XDG_CACHE_HOME="$PWD/cache" XDG_RUNTIME_DIR="$PWD/runroot" TMPDIR="$PWD/scratch"
export NVIDIA_VISIBLE_DEVICES=void
mkdir -p hooks cuda-bin cuda-lib cuda-build
pman() {
 podman --root "$PWD/storage" --runroot "$PWD/runroot" --tmpdir "$PWD/podman-tmp" --storage-driver vfs --cgroup-manager cgroupfs --events-backend file "$@"
}
if ! pman image exists localhost/cuda-devel:bench786; then
 pman pull "oci:$PWD/cuda-devel-oci"
fi
pman tag sha256:154bd2b08b4ccf152598c633958f4da7426d27a160d877fd8ccecb266285e35a localhost/cuda-devel:bench786
pman image inspect localhost/cuda-devel:bench786 > cuda-build-image.json
rm -rf cuda-devel-oci
pman run --rm --name usnm-pair-786-build --hooks-dir "$PWD/hooks" --network none --security-opt no-new-privileges --pids-limit 1024 --cpus 4 -v "$PWD:/work" -w /work -e HOME=/work/home -e TMPDIR=/work/scratch -e XDG_CACHE_HOME=/work/cache -e NVIDIA_VISIBLE_DEVICES=void localhost/cuda-devel:bench786 sh -eu -c '
 /work/cmake-3.31.6-linux-x86_64/bin/cmake --version
 nvcc --version
 g++ --version
 /work/cmake-3.31.6-linux-x86_64/bin/cmake -S source -B cuda-build -DGGML_NATIVE=OFF -DGGML_CUDA=ON -DGGML_BACKEND_DL=ON -DCMAKE_CUDA_ARCHITECTURES=75 -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_CURL=OFF -DLLAMA_OPENSSL=OFF -DCMAKE_BUILD_TYPE=Release
 /work/cmake-3.31.6-linux-x86_64/bin/cmake --build cuda-build --target llama-server ggml-cuda ggml-cpu -j4
 cp -P cuda-build/bin/llama-server cuda-build/bin/*.so* cuda-bin/
 cp -P /usr/local/cuda/targets/x86_64-linux/lib/libcudart.so* /usr/local/cuda/targets/x86_64-linux/lib/libcublas.so* /usr/local/cuda/targets/x86_64-linux/lib/libcublasLt.so* cuda-lib/
 cp -P /usr/lib/x86_64-linux-gnu/libnccl.so* cuda-lib/
 '
sha256sum cuda-bin/llama-server cuda-bin/libggml-cuda.so > cuda-build-sha256.txt
LD_LIBRARY_PATH="$PWD/cuda-bin:$PWD/cuda-lib" ldd cuda-bin/llama-server > cuda-build-ldd.txt

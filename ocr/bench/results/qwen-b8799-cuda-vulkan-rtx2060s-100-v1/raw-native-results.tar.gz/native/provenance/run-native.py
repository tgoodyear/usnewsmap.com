import argparse,datetime,json,os,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('backend',choices=['cuda','vulkan']);p.add_argument('--deadline',required=True,type=float);args=p.parse_args()
root=Path(__file__).resolve().parent;os.chdir(root)
def command(cmd,**kw):return subprocess.run(cmd,capture_output=True,text=True,timeout=15,**kw)
def boinc_busy():
 r=command(['boinccmd','--get_tasks'],cwd='/var/lib/boinc-client')
 if r.returncode:raise RuntimeError('Unable to verify BOINC idleness: '+r.stderr)
 return any(('active_task_state: EXECUTING' in x or 'active_task_state: RUNNING' in x or 'scheduler state: scheduled' in x) for x in r.stdout.splitlines())
def gpu_processes():
 r=command(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'])
 if r.returncode:raise RuntimeError(r.stderr)
 if r.stdout.strip():return r.stdout.strip()
 m=command(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'])
 if m.returncode:raise RuntimeError(m.stderr)
 return 'GPU memory is not idle' if float(m.stdout.strip())>0 else ''
def descendants(pid):
 rows=command(['ps','-eo','pid=,ppid=']).stdout.splitlines();pairs=[tuple(map(int,x.split())) for x in rows];result={pid}
 while True:
  more={a for a,b in pairs if b in result}
  if more<=result:return result
  result|=more

def stop_own(child):
 owned=descendants(child.pid)
 for pid in sorted(owned,reverse=True):
  try:os.kill(pid,signal.SIGTERM)
  except ProcessLookupError:pass
 deadline=time.monotonic()+10
 while time.monotonic()<deadline and any(Path(f'/proc/{pid}').exists() for pid in owned):time.sleep(.2)
 for pid in owned:
  try:
   if Path(f'/proc/{pid}/cwd').resolve().is_relative_to(root):os.kill(pid,signal.SIGKILL)
  except (ProcessLookupError,FileNotFoundError):pass
 child.wait(timeout=5)

env=os.environ.copy();env.update({'HOME':str(root/'home'),'TMPDIR':str(root/'scratch'),'XDG_CACHE_HOME':str(root/'cache'),'__GL_SHADER_DISK_CACHE_PATH':str(root/'cache'/'nvidia'),'USNM_QWEN_MODEL_DIR':'/var/lib/boinc-client/native-models'})
server=root/('cuda-bin/llama-server' if args.backend=='cuda' else 'vulkan/llama-b8799/llama-server')
env['USNM_LLAMA_SERVER']=str(server)
env['LD_LIBRARY_PATH']=str(server.parent)+':'+str(root/'cuda-lib')+':'+env.get('LD_LIBRARY_PATH','')
if args.backend=='vulkan':env['VK_ICD_FILENAMES']='/usr/share/vulkan/icd.d/nvidia_icd.json'
slots=root/(args.backend+'-slots');stage=json.loads((slots/'qwen-bench.json').read_text())
receipt={'backend':args.backend,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'slots':[],'deadline_epoch':args.deadline}
start=time.monotonic();child=None
try:
 with (root/(args.backend+'-telemetry.jsonl')).open('a',buffering=1) as telemetry:
  for job in stage['slots']:
   slot=slots/job
   if (slot/'boinc_finish_called').is_file() and (slot/'boinc_finish_called').read_text().strip()=='0':continue
   if time.time()>=args.deadline:raise RuntimeError('Reservation deadline reached before slot')
   if boinc_busy() or gpu_processes():raise RuntimeError('Yielding before slot to active BOINC/GPU work')
   t=time.monotonic();f=(slot/'worker-console.log').open('a')
   child=subprocess.Popen([str(root/'usnm_qwen')],cwd=slot,env=env,stdout=f,stderr=f,start_new_session=True)
   check=0
   while child.poll() is None:
    if time.time()>=args.deadline:raise RuntimeError('Reservation deadline reached during slot')
    if time.monotonic()>=check:
     if boinc_busy():raise RuntimeError('Yielding immediately to newly active BOINC task')
     check=time.monotonic()+10
    r=command(['nvidia-smi','--query-gpu=memory.used,utilization.gpu,power.draw','--format=csv,noheader,nounits'])
    if r.returncode:raise RuntimeError(r.stderr)
    values=r.stdout.strip().split(',');row={'epoch':time.time(),'job_id':job,'gpu_mib':float(values[0]),'utilization_pct':float(values[1]),'board_w':float(values[2])}
    pids=descendants(child.pid);rss=0
    for pid in pids:
     try:
      for line in Path(f'/proc/{pid}/status').read_text().splitlines():
       if line.startswith('VmRSS:'):rss+=int(line.split()[1])
     except FileNotFoundError:pass
    row['process_rss_kib']=rss;telemetry.write(json.dumps(row)+'\n');time.sleep(1)
   f.close();receipt['slots'].append({'job_id':job,'elapsed_s':time.monotonic()-t,'exit_code':child.returncode});print(json.dumps(receipt['slots'][-1]),flush=True)
   if child.returncode:raise RuntimeError('Worker failed; inspect private output before continuing')
   child=None
except BaseException as e:
 receipt['error']=str(e)
 if child is not None and child.poll() is None:stop_own(child)
 raise
finally:
 receipt['elapsed_s']=time.monotonic()-start;receipt['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(root/(args.backend+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
